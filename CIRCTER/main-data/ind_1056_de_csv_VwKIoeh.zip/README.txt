# ESPON package for the indicator 'DE'

This readme file describes the content of this Indicator package.


## Information

- Name: Domestic Extraction
- Code: DE
- Id: 1056


### Abstract

Domestic extraction (DE) is the input from the natural environment to be used in the economy. DE is the annual amount of raw material (except for water and air) extracted from the natural environment.


## File(s)

- README.txt: This file
- ind_1056_de_data.csv: Data file
- ind_1056_de_data.xls: Data file
- ind_1056_de_metadata_inspire.xml: Metadata Inspire
- ind_1056_de_metadata_espon.pdf: Metadata ESPON


### Columns descriptions for Data file

- id: Indicator id
- name: Indicator name
- code: Indicator code
- nomenclature: Territorial nomenclature name
- level: Territorial nomenclature level
- version: Territorial nomenclature version
- tunit_code: Territorial unit code
- tunit_name: Territorial unit name
- processes: Data items processes
- sources: Data items source
- y_<int>: Data items values covered by the <int> year

