# ESPON package for the indicator 'DMC'

This readme file describes the content of this Indicator package.


## Information

- Name: Domestic Material Consumption
- Code: DMC
- Id: 1055


### Abstract

DMC measures the total amount of materials directly used by an economy and is defined as the annual quantity of raw materials extracted from the domestic territory, plus all physical imports minus all physical exports. The DMC indicator provides an assessment of the absolute level of the use of resources, and allows to distinguish consumption driven by domestic demand from consumption driven by the export market. It is important to note that the term &quot;consumption&quot; as used in DMC denotes apparent consumption and not final consumption. DMC does not include upstream &quot;hidden&quot; flows related to imports and exports of raw materials and products.


## File(s)

- README.txt: This file
- ind_1055_dmc_data.csv: Data file
- ind_1055_dmc_data.xls: Data file
- ind_1055_dmc_metadata_inspire.xml: Metadata Inspire
- ind_1055_dmc_metadata_espon.pdf: Metadata ESPON


### Columns descriptions for Data file

- id: Indicator id
- name: Indicator name
- code: Indicator code
- nomenclature: Territorial nomenclature name
- level: Territorial nomenclature level
- version: Territorial nomenclature version
- tunit_code: Territorial unit code
- tunit_name: Territorial unit name
- processes: Data items processes
- sources: Data items source
- y_<int>: Data items values covered by the <int> year

