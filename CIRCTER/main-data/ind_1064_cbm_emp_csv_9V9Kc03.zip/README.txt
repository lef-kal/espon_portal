# ESPON package for the indicator 'CBM_EMP'

This readme file describes the content of this Indicator package.


## Information

- Name: Circular economy business models (employment)
- Code: CBM_EMP
- Id: 1064


### Abstract

The indicator measures the total employment in Circular Business Models (CBM) sectors. The CBMs facilitate the up-take of circular processes through innovative services and new forms of consumption by connecting businesses to businesses (B2B), businesses to consumers (B2C) and consumers to consumers (C2C).The CBMs can be categorised as focusing either on consumers or on products but are not mutually exclusive. Primarily focusing on consumers are the Business Models Access and Performance models, that provide products as a service, and Encourage sufficiency and shift utilisation patterns, that seek to reduce end-user consumption. Targeted at products are the Models Extending Product and Resource Value by exploiting the residual value of products, and Long-Life Design, focused on a design for durability, repair and material productivity. The indicator is estimated according to latest available years (2018 and previous years).


## File(s)

- README.txt: This file
- ind_1064_cbm_emp_data.csv: Data file
- ind_1064_cbm_emp_data.xls: Data file
- ind_1064_cbm_emp_metadata_inspire.xml: Metadata Inspire
- ind_1064_cbm_emp_metadata_espon.pdf: Metadata ESPON


### Columns descriptions for Data file

- id: Indicator id
- name: Indicator name
- code: Indicator code
- nomenclature: Territorial nomenclature name
- level: Territorial nomenclature level
- version: Territorial nomenclature version
- tunit_code: Territorial unit code
- tunit_name: Territorial unit name
- processes: Data items processes
- sources: Data items source
- y_<int>: Data items values covered by the <int> year

