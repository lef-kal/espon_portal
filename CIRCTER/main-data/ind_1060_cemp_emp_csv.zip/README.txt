# ESPON package for the indicator 'CEMP_EMP'

This readme file describes the content of this Indicator package.


## Information

- Name: Circular economy material providers (employment)
- Code: CEMP_EMP
- Id: 1060


### Abstract

The indicator measures the total employment in Material Providers sectors. In a Circular Economy, Material Providers represent mainly the biological cycles but also those essential services that reintroduce wastes as a resource into existing value chains. Simply put, Material Providers form the basic input-side by providing materials and renewable energy for a Circular Economy that are comprised of renewable and recycled materials. Illustrative examples are the market segments forestry, sustainable agriculture and renewable energy along with the production of high-quality secondary raw materials from wastes, that is the collection and recycling services.


## File(s)

- README.txt: This file
- ind_1060_cemp_emp_data.csv: Data file
- ind_1060_cemp_emp_data.xls: Data file
- ind_1060_cemp_emp_metadata_inspire.xml: Metadata Inspire
- ind_1060_cemp_emp_metadata_espon.pdf: Metadata ESPON


### Columns descriptions for Data file

- id: Indicator id
- name: Indicator name
- code: Indicator code
- nomenclature: Territorial nomenclature name
- level: Territorial nomenclature level
- version: Territorial nomenclature version
- tunit_code: Territorial unit code
- tunit_name: Territorial unit name
- processes: Data items processes
- sources: Data items source
- y_<int>: Data items values covered by the <int> year

