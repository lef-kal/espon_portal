# ESPON package for the indicator 'CETP_EMP'

This readme file describes the content of this Indicator package.


## Information

- Name: Circular economy technology Providers (employment)
- Code: CETP_EMP
- Id: 1062


### Abstract

The indicator measures the total employment in Technology Providers sectors. Technology Providers provide technologies and key services that enable cyclical resource flows and more efficient use. They also provide intermediate products representing the technological cycle that, in many ways, enable the implementation of Circular Economy processes through innovative technologies and resource-saving services throughout the value chain. Technology Providers’ contribution to value generation is to recover and restore materials, components and products through the provision of technologies and services that aid the reuse, repair, recycling and re-manufacture of durables and turn wastes into resources and use energy more efficiency. Technology Providers include the production of consumables from Eco-friendly materials, such as natural fibres, bio-plastics or composite materials, or technologies for the generation of renewable raw materials or energy, as well as installations and machinery for the treatment of material streams.


## File(s)

- README.txt: This file
- ind_1062_cetp_emp_data.csv: Data file
- ind_1062_cetp_emp_data.xls: Data file
- ind_1062_cetp_emp_metadata_inspire.xml: Metadata Inspire
- ind_1062_cetp_emp_metadata_espon.pdf: Metadata ESPON


### Columns descriptions for Data file

- id: Indicator id
- name: Indicator name
- code: Indicator code
- nomenclature: Territorial nomenclature name
- level: Territorial nomenclature level
- version: Territorial nomenclature version
- tunit_code: Territorial unit code
- tunit_name: Territorial unit name
- processes: Data items processes
- sources: Data items source
- y_<int>: Data items values covered by the <int> year

